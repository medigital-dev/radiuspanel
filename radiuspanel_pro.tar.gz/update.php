<?php
shell_exec("wget https://github.com/medigital-dev/radiuspanel/archive/refs/tags/v1.1.tar.gz");
shell_exec("mv v1.1.tar.gz /tmp");
// shell_exec("tar zxvf /tmp/v1.1.tar.gz -C /usr/share/radiuspanel");
// echo exec('curl --silent "https://api.github.com/repos/medigital-dev/radiuspanel/releases/latest"');
echo true;
